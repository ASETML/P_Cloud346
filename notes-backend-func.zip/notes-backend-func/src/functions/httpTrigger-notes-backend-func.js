const { app } = require("@azure/functions");
const { getDb } = require("../db/dbConfig");

app.http("EvaluationsHandler", {
  methods: ["GET", "POST"], //We allow both receiving and sending evaluations
  route: "books/{bookId}/evaluations", // {bookId} — This is a dynamic parameter from the URL.
  authLevel: "anonymous",
  handler: async (request, context) => {
    const db = await getDb(); // Getting a connection to the database
    const bookId = request.params.bookId; // Get the book ID from the URL

    // --- GET ---
    if (request.method === "GET") {
      try {
        if (!bookId)
          return { status: 400, jsonBody: { message: "Book ID required" } };

        const evaluations = await db.Evaluate.findAll({
          where: { book_id: bookId },
          include: [
            {
              model: db.User,
              as: "user",
              attributes: ["username"], // users names
            },
            {
              model: db.Book,
              as: "t_livre",
              attributes: ["titre"],
            },
          ],
          order: [["created", "DESC"]],
        });

        return { status: 200, jsonBody: evaluations };
      } catch (error) {
        context.error(error);
        return { status: 500, jsonBody: { message: error.message } };
      }
    }

    // --- POST ---
    if (request.method === "POST") {
      try {
        // In Azure v4, the body is obtained via request.json()
        const body = await request.json();
        const { commentaire, note, user_id } = body;

        if (!bookId || !user_id || note === undefined) {
          return {
            status: 400,
            jsonBody: { message: "Missing fields (note, user_id)" },
          };
        }

        const evaluation = await db.Evaluate.create({
          commentaire,
          note,
          user_id,
          book_id: bookId,
        });

        return { status: 201, jsonBody: evaluation };
      } catch (error) {
        context.error(error);
        return { status: 500, jsonBody: { message: error.message } };
      }
    }
  },
});
