const { app } = require("@azure/functions");
const { getDb } = require("../db/dbConfig");

// 1. GET Evaluations for a Book
// Route: /api/books/{bookId}/evaluations
app.http("GetEvaluationsForBook", {
  methods: ["GET"],
  route: "books/{bookId}/evaluations",
  authLevel: "anonymous",
  handler: async (request, context) => {
    try {
      const db = await getDb();
      const { bookId } = request.params;

      if (!bookId)
        return { status: 400, jsonBody: { message: "Book ID required" } };

      const evaluations = await db.Evaluate.findAll({
        where: { book_id: bookId },
        include: [
          { model: db.User, as: "user", attributes: ["username"] },
          { model: db.Book, as: "t_livre", attributes: ["titre"] },
        ],
        order: [["created", "DESC"]],
      });

      return { status: 200, jsonBody: evaluations };
    } catch (error) {
      context.error(error);
      return { status: 500, jsonBody: { message: error.message } };
    }
  },
});

// 2. CREATE Evaluation
// Route: /api/books/{bookId}/evaluations
app.http("CreateEvaluation", {
  methods: ["POST"],
  route: "books/{bookId}/evaluations",
  authLevel: "anonymous",
  handler: async (request, context) => {
    try {
      const db = await getDb();
      const { bookId } = request.params;
      const body = await request.json();
      const { commentaire, note, user_id } = body;

      if (!bookId || !user_id || note === undefined) {
        return { status: 400, jsonBody: { message: "Missing fields" } };
      }

      const evaluation = await db.Evaluate.create({
        commentaire,
        note,
        user_id,
        book_id: bookId,
      });

      return { status: 201, jsonBody: evaluation };
    } catch (error) {
      context.error(error);
      return { status: 500, jsonBody: { message: error.message } };
    }
  },
});

// 3. GET Evaluation by ID
// Route: /api/evaluations/{noteId}
app.http("GetEvaluationById", {
  methods: ["GET"],
  route: "evaluations/{noteId}",
  authLevel: "anonymous",
  handler: async (request, context) => {
    try {
      const db = await getDb();
      const { noteId } = request.params;

      const evaluation = await db.Evaluate.findOne({
        where: { id: noteId },
        include: [{ model: db.Book, as: "t_livre" }],
      });

      if (!evaluation)
        return { status: 404, jsonBody: { message: "Not found" } };

      return { status: 200, jsonBody: evaluation };
    } catch (error) {
      return { status: 500, jsonBody: { message: "Server error" } };
    }
  },
});

// 4. GET Evaluations by User ID
// Route: /api/users/{userId}/evaluations
app.http("GetEvaluationsByUserId", {
  methods: ["GET"],
  route: "users/{userId}/evaluations",
  authLevel: "anonymous",
  handler: async (request, context) => {
    try {
      const db = await getDb();
      const { userId } = request.params;

      const evaluations = await db.Evaluate.findAll({
        where: { user_id: userId },
      });

      if (!evaluations)
        return { status: 404, jsonBody: { message: "Not found" } };

      return { status: 200, jsonBody: evaluations };
    } catch (error) {
      return { status: 500, jsonBody: { message: "Server error" } };
    }
  },
});

// 5. UPDATE Evaluation
// Route: /api/evaluations/{noteId}
app.http("UpdateEvaluation", {
  methods: ["PUT"],
  route: "evaluations/{noteId}",
  authLevel: "anonymous",
  handler: async (request, context) => {
    try {
      const db = await getDb();
      const { noteId } = request.params;
      const { commentaire, note } = await request.json();

      const evaluation = await db.Evaluate.findOne({ where: { id: noteId } });

      if (!evaluation)
        return { status: 404, jsonBody: { message: "Not found" } };

      evaluation.commentaire = commentaire;
      evaluation.note = note;
      await evaluation.save();

      return { status: 200, jsonBody: evaluation };
    } catch (error) {
      return { status: 500, jsonBody: { message: "Server error" } };
    }
  },
});

// 6. DELETE Evaluation
// Route: /api/evaluations/{noteId}
app.http("DeleteEvaluation", {
  methods: ["DELETE"],
  route: "evaluations/{noteId}",
  authLevel: "anonymous",
  handler: async (request, context) => {
    try {
      const db = await getDb();
      const { noteId } = request.params;

      const evaluation = await db.Evaluate.findOne({ where: { id: noteId } });

      if (!evaluation)
        return { status: 404, jsonBody: { message: "Not found" } };

      await evaluation.destroy();

      return { status: 200, jsonBody: { message: "Deleted successfully" } };
    } catch (error) {
      return { status: 500, jsonBody: { message: "Server error" } };
    }
  },
});
