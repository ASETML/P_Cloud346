module.exports = (sequelize, DataTypes) => {
  const User = sequelize.define(
    "t_user",
    {
      utilisateur_id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true,
        allowNull: false,
      },
      hashed_password: {
        type: DataTypes.STRING,
        allowNull: false,
        unique: { msg: "Hash already exists." },
      },
      username: {
        type: DataTypes.STRING,
        allowNull: false,
        unique: { msg: "This username is already taken." },
      },
      ms_id: {
        type: DataTypes.STRING,
        unique: true,
        allowNull: true,
      },
      email: {
        type: DataTypes.STRING,
        allowNull: true,
      },
      isAdmin: {
        type: DataTypes.BOOLEAN,
        allowNull: false,
        defaultValue: false, // Fixed syntax from 'default' to 'defaultValue' for Sequelize
      },
    },
    {
      timestamps: true,
      createdAt: true,
      updatedAt: false,
      freezeTableName: true,
    }
  );

  return User;
};
