module.exports = (sequelize, DataTypes) => {
  const Evaluate = sequelize.define(
    "t_evaluer",
    {
      commentaire: {
        type: DataTypes.STRING,
        allowNull: true,
      },
      note: {
        type: DataTypes.INTEGER,
        allowNull: false,
        validate: {
          min: {
            args: [0],
            msg: "Rating must be at least 0",
          },
          max: {
            args: [10],
            msg: "Rating cannot exceed 10",
          },
        },
      },
      user_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
      },
      book_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
      },
    },
    {
      timestamps: true,
      createdAt: "created",
      updatedAt: "updated",
      freezeTableName: true,
    }
  );

  // Define Associations
  Evaluate.associate = (models) => {
    Evaluate.belongsTo(models.t_user, {
      foreignKey: "user_id",
      as: "user",
      onDelete: "CASCADE",
    });
    Evaluate.belongsTo(models.t_livre, {
      foreignKey: "book_id",
      as: "t_livre",
      onDelete: "CASCADE",
    });
  };

  return Evaluate;
};
