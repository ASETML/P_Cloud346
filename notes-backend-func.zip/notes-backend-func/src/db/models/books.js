module.exports = (sequelize, DataTypes) => {
  const Book = sequelize.define(
    "t_livre",
    {
      livre_id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true,
      },
      titre: {
        type: DataTypes.STRING,
        allowNull: false,
        unique: {
          msg: "This title is already taken.",
        },
        validate: {
          notEmpty: { msg: "Title cannot be empty." },
          notNull: { msg: "Title is mandatory." },
        },
      },
      annee_edition: {
        type: DataTypes.INTEGER,
        allowNull: false,
        validate: {
          isInt: { msg: "Year must be an integer." },
          max: {
            args: [2025],
            msg: "Year must be 2025 or earlier.",
          },
        },
      },
      lien_image: {
        type: DataTypes.STRING,
        allowNull: true,
      },
      lien_pdf: {
        type: DataTypes.STRING,
        allowNull: true,
      },
      resume: {
        type: DataTypes.TEXT,
        allowNull: true,
      },
      editeur: {
        type: DataTypes.STRING,
        allowNull: true,
      },
      nombre_de_page: {
        type: DataTypes.INTEGER,
        allowNull: false,
        validate: {
          isInt: { msg: "Page count must be an integer." },
          min: {
            args: [1],
            msg: "Book must have at least one page.",
          },
        },
      },
      category_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
      },
      writer_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
      },
      user_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
      },
    },
    {
      timestamps: true,
      createdAt: "created",
      updatedAt: "updated",
      freezeTableName: true,
    }
  );

  // Define Associations
  Book.associate = (models) => {
    Book.belongsTo(models.t_category, {
      foreignKey: "category_id",
      targetKey: "categorie_id",
      as: "category",
      onDelete: "CASCADE",
    });
    Book.belongsTo(models.t_ecrivain, {
      foreignKey: "writer_id",
      targetKey: "ecrivain_id",
      as: "writer",
      onDelete: "CASCADE",
    });
  };

  return Book;
};
