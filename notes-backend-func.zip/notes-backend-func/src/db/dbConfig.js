const { Sequelize, DataTypes } = require("sequelize");
// Import models
const UserModel = require("./models/user");
const BookModel = require("./models/book");
const EvaluateModel = require("./models/evaluate");
const WriterModel = require("./models/writer");
const CategoryModel = require("./models/category");

//  mysql://albyos:...
const connectionString = process.env.SQL_CONNECTION_STRING;

let db = {};

async function getDb() {
  if (db.sequelize) {
    return db;
  }

  if (!connectionString) {
    throw new Error("SQL_CONNECTION_STRING not found in settings!");
  }

  // connection to MySQL
  const sequelize = new Sequelize(connectionString, {
    dialect: "mysql",
    logging: false,
    dialectOptions: {
      ssl: {
        require: true,
        rejectUnauthorized: false, // for Azure MySQL
      },
    },
  });

  // Initialize models
  db.t_user = UserModel(sequelize, DataTypes);
  db.t_ecrivain = WriterModel ? WriterModel(sequelize, DataTypes) : null;
  db.t_category = CategoryModel ? CategoryModel(sequelize, DataTypes) : null;
  db.t_livre = BookModel(sequelize, DataTypes);
  db.t_evaluer = EvaluateModel(sequelize, DataTypes);

  // Aliases for easier access
  db.User = db.t_user;
  db.Book = db.t_livre;
  db.Evaluate = db.t_evaluer;

  // Associations
  Object.keys(db).forEach((modelName) => {
    if (db[modelName] && db[modelName].associate) {
      db[modelName].associate(db);
    }
  });

  db.sequelize = sequelize;
  db.Sequelize = Sequelize;

  return db;
}

module.exports = { getDb };
