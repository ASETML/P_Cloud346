let writers = [
  {
    prenom: "Ajak",
    nom_de_famille: "Semak",
  },
  {
    prenom: "Auderey",
    nom_de_famille: "Makashi",
  },
  {
    prenom: "Vimil-eeet",
    nom_de_famille: "dunon non mi",
  },
  {
    prenom: "Amid-vulcain-charbon",
    nom_de_famille: "Dupondt",
  },
  {
    prenom: "Jean",
    nom_de_famille: "dunon non m",
  },
];
export { writers };
