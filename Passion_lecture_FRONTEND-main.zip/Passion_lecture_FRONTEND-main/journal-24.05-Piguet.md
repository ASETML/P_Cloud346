**obectifs**
- avancer dans le projet passion lecture Frontend pour m. Charmier
    - terminer les pages de login/register
    - terminer la gestion des tokens jwt 
- commencer le rapport si le temps le permet


**travail effectué**
- j'ai terminé les pages de login et de register pour qu'elles connectent automatiquement le user si il a un token et sinon, 
    un token est mis dans localStorage ainsi que l'id après que le formulaire ait été validé
- j'ai modifié la page CreateBook pour que le user qui créé soit le bon. j'ai du faire beaucoup de débogage pour bien comprendre comment transmettre le userId
- j'ai du modifier le backend pour que le userId reçu soit le bon
- j'ai fait beaucoup de test et de debug de l'application
- j'ai vérifié que toutes les nouvelles routes fonctionnent ainsi que l'authentification, les fonctionnalités du crud etc...
- j'ai beaucoup debug lorsqu'il y avait des erreurs

- j'ai terminé par lire une documentation sur les WebSockets et leur utilisations dans différents domaines
    - https://developer.mozilla.org/en-US/docs/Web/API/WebSockets_API
    - https://www.youtube.com/watch?v=xTR5OflgwgU&pp=0gcJCdgAo7VqN5tD
    - https://www.youtube.com/watch?v=KPfi5sRiRVY

**Conclusion**

- je suis content de mon travail car l'app doit être quasi terminée, je dois juste montrer mes changements au reste de l'équipe et 
    comparer une dernière fois l'app avec le CdC et tester à nouveau toutes les fonctionnalités.
- une fois que les vérifications seront passées, on pourra accomplir la dernière tâche, le rapport.
- les modifications que j'ai ajoutées étaient essentielles au bon fonctionnement de l'app